package com.example.shree.lazyloading_of_images;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import static com.example.shree.lazyloading_of_images.R.id.listView;

public class MainActivity extends AppCompatActivity {

    List<SingleRowItemPojo> arrayList;
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        arrayList = new ArrayList<>();
        lv = (ListView) findViewById(listView);

        new MyTask().execute();
    }


    class MyTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            StringBuilder content = new StringBuilder();
            try {
                String theUrl = "http://www.androidbegin.com/tutorial/jsonparsetutorial.txt";

                // create a url object
                URL url = new URL(theUrl);
                // create a urlconnection object
                URLConnection urlConnection = url.openConnection();
                // wrap the urlconnection in a bufferedreader
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                String line;
                // read from the urlconnection via the bufferedreader
                while ((line = bufferedReader.readLine()) != null) {
                    content.append(line + "\n");
                }
                bufferedReader.close();

                JSONObject jsonObject = new JSONObject(String.valueOf(content));

                JSONArray jsonArray = jsonObject.getJSONArray("worldpopulation");

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject productObject = jsonArray.getJSONObject(i);
                    arrayList.add(new SingleRowItemPojo(
                            productObject.getString("flag"),
                            productObject.getString("rank"),
                            productObject.getString("country")
                    ));
                }

                final CustomAdapter customAdapter = new CustomAdapter(MainActivity.this, arrayList);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        lv.setAdapter(customAdapter);
                    }
                });


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}